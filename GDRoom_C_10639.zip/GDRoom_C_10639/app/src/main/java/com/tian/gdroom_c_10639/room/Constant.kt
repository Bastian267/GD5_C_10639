package com.tian.gdroom_c_10639.room

class Constant {
    companion object{
        const val TYPE_READ     = 0
        const val TYPE_CREATE   = 1
        const val TYPE_UPDATE   = 2
    }
}